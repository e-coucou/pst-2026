import { readFileSync } from 'fs';
import { join } from 'path';

/**
 * GET /api/charte
 * Retourne le contenu du fichier CHARTE-GRAPHIQUE-PST.md
 */
export async function GET() {
  try {
    // Chemin vers le fichier markdown à la racine du projet
    const filePath = join(process.cwd(), 'CHARTE-GRAPHIQUE-PST.md');
    
    // Lecture du fichier
    const content = readFileSync(filePath, 'utf-8');
    
    // Retour avec cache headers
    return new Response(JSON.stringify({ content }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=86400',
      },
    });
  } catch (error) {
    console.error('Erreur lors de la lecture du fichier charte:', error);
    
    return new Response(
      JSON.stringify({ 
        error: 'Impossible de charger la charte graphique',
        message: error instanceof Error ? error.message : 'Erreur inconnue'
      }),
      {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      }
    );
  }
}
